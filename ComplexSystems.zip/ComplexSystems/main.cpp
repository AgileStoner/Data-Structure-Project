//
//  main.cpp
//  ComplexSystems
//
//  Created by Asadulla Kudrateellaev on 04/12/22.
//

#include <iostream>
#include <string>
#include "HashTable.hpp"
#include "Client.hpp"
using namespace std;


Hash ClientRecords(100);


int inputInt(int low_bound, int up_bound){
    int i;
    while (true)
    {
        cin >> i;
        if (!cin or i < low_bound or i > up_bound)
        {
            cout << "Wrong Choice. Enter again " << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }
        else break;
    }
    return i;
}

void EnterComplex(){
    system("CLS");
    while(true){
        cout << "Enter Phone Number: +998 ";
        string phone;
        cin >> phone;
        if(phone.length() != 9){
            system("CLS");
            cout << "Incorrect amount of digits!" << endl;
            continue;
        }
        for (int i = 0; i <= 9; i++){
            if(!isdigit(phone[i])){
                system("CLS");
                cout << "Number includes chars" << endl;
                continue;
            }
        }
        break;
    }
    
    
    
}


void menu(){
    
    cout << "1. Enter complex" << endl;
    cout << "2. Leave complex" << endl;
    cout << "3. Add client" << endl;
    cout << "4. Edit client" << endl;
    cout << "5. Currently in complex clients"<< endl;
    cout << "6. All clients" << endl;
    int choice = inputInt(1, 6);
    
}



int main(int argc, const char * argv[]) {
    menu();
    
    return 0;
}
