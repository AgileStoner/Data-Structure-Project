//
//  HashTable.cpp
//  ComplexSystems
//
//  Created by Asadulla Kudrateellaev on 04/12/22.
//

#include "HashTable.hpp"

Hash::Hash(int b)
{
    this->BUCKET = b;
    table = new Linkedlist[BUCKET];
}


int Hash::hashFunction(Client user) {
    int l = user.getPhone().length();
    int convert;
    int sum = 0;
    for (int i = 0; i < l; i++) {
        convert = user.getPhone()[i];
        sum += convert;
    }
    return (sum % BUCKET);
}


void Hash::insertItem(Client user)
{
    int index = hashFunction(user);
    //table[index].push_back(user.getNumber());
    table[index].insertNode(user.getID(), user.getName(), user.getPhone(), user.getSub());
}
    
Node* Hash::searchItem(Client user){
    int index = hashFunction(user);
    int NodeIndex = table[index].getIndex(user.getPhone());
    if (NodeIndex == -1){
        cout << "The key does not exist" << endl;
        return NULL;
    }
    return table[index].getNodeAddress(NodeIndex);
}
 
void Hash::deleteItem(Client user)
{
    // get the hash index of key
    int index = hashFunction(user);
    
    // find the key in (index)th list
    int ListIndex = table[index].getIndex(user.getPhone());
    if (ListIndex == -1){
        cout << "The key does not exist"<<endl;
        return;
    }
    table[index].deleteNode(ListIndex);
}
 
// function to display hash table
void Hash::displayHash() {
    for (int i = 0; i < BUCKET; i++){
        cout << "Index: " << i;
        table[i].printList();
        cout << endl;
    }
}
