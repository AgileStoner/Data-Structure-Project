//
//  Client.hpp
//  ComplexSystems
//
//  Created by Asadulla Kudrateellaev on 04/12/22.
//

#ifndef Client_hpp
#define Client_hpp

#include <stdio.h>
#include <iostream>
#include <string>
#include "LinkedList.hpp"
using namespace std;

class Client{
private:
    static int count;
    int id;
    string name;
    string phone;
    int subscription;
    Linkedlist fields;
public:
    Client(){
        id = ++count;
    }
    Client(string phone, string name, int subscription){
        this->name = name;
        this->phone = phone;
        this->subscription = subscription;
        fields.insertNode(this->id, this->name, this->phone, this->subscription);
    }
    string getName(){
        return name;
    }
    void setName(string NAME){
        name = NAME;
    }
    int getID(){
        return id;
    }
    string getPhone(){
        return phone;
    }
    void setPhone(int NUM){
        phone = NUM;
    }
    int getSub(){
        return subscription;
    }
    void setSub(int Sub){
        subscription = Sub;
    }
    Linkedlist getFields(){
        return fields;
    }
    void setFields(Linkedlist f) {
        fields = f;
    }
};

#endif /* Client_hpp */
